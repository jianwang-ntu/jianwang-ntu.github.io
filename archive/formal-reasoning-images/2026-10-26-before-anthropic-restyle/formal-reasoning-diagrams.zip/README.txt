Four research diagrams created with ChatGPT Create image. PNGs are the full-resolution raster exports. Website: https://www.wj2ai.com/statement/
