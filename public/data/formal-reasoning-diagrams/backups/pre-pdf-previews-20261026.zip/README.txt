Original published PNG and WebP research figures preserved before replacement with previews exported from the editable PowerPoint PDF.
Backup date: 26 October 2026.
SHA256.json records repository paths and original file checksums.
