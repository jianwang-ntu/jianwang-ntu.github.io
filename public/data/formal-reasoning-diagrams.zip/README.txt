Formal reasoning proposed research diagrams — 26 October 2026

Context sources:
https://www.anthropic.com/research/formal-verification
https://theorem.dev/blog/verified-software-stack/

These diagrams depict Jian Wang's proposed experiments; they do not claim the cited projects as his results.
Four high-resolution PNGs generated with ChatGPT Create image in connected Chrome. These are raster assets, not editable vector masters.
